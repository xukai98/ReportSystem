1、npm install
2、npm run dev

注：转载使用请注明。