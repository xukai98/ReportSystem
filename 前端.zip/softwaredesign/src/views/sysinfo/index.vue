<template>
  <div>
    <div style="padding: 10px;"></div>
    <el-tag type="success" style="font-size: larger;">系统环境：</el-tag><div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">Python3.6+Node.js+CUDA10.0</div>
    <div style="padding: 10px;"></div>
    <el-tag type="success" style="font-size: larger;">系统架构：</el-tag><div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">本系统采用前后端分离架构实现，前后端通过JSON格式进行交互，前后端可独立部署。前端核心框架使用Vue.js,UI使用饿了么开源的Element，前后端交互使用了axios。后端使用Flask,选择使用PostgreSQL关系型数据库和Neo4j图数据库。</div>
    <div style="padding: 10px;"></div>
    <el-tag type="success" style="font-size: larger;">开发语言：</el-tag><div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">HTML+CSS+JS+Python</div>
    <div style="padding: 10px;"></div>
    <el-tag type="success" style="font-size: larger;">系统特点：</el-tag><div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">运行NLP技术和深度学习技术，训练因果关系抽取模型从网络信息中抽取因果关系构造领域因果关系的知识图谱，在生成报告的过程中对某些指标的上升和下降进行推理分析。</div>
  </div>
</template>

<script>
</script>

<style>
</style>
