<template>
  <div class="app-container">
    <el-table
      :data="reportTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
      style="width: 100%">
      <el-table-column fixed prop="date" sortable label="生成日期">
      </el-table-column>
      <el-table-column prop="name" label="负责人">
      </el-table-column>
      <el-table-column prop="phonenum" label="联系方式">
      </el-table-column>
      </el-table-column>
      <el-table-column prop="filename" label="文件名称">
      </el-table-column>
      <el-table-column prop="filesize" sortable label="文件大小">
      </el-table-column>
      <el-table-column prop="url" label="报告存储路径">
      </el-table-column>
      <el-table-column align="right" width="300px">
        <template slot="header" slot-scope="scope">
          <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
        </template>
        <template slot-scope="scope">
          <el-button size="mini" type="primary" @click="reportDownload(scope.$index,scope.row)"><i
              class="el-icon-download"></i>下载</el-button>
          <el-button size="mini" type="danger" @click="handleReportDelete(scope.$index, scope.row)"><i
              class="el-icon-delete"></i>移除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="block" align="center" style="margin-top: 10px;">
      <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
        :page-sizes="pageSizes" :page-size="PageSize" layout="total, sizes, prev, pager, next, jumper" :total=total>
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import Vue from 'vue'
  export default {
    data() {
      return {
        reportTable: [],
        search: '',
        currentPage: 1,
        total: 0,
        pageSizes: [5, 10, 20, 50],
        PageSize: 5,
      }
    },
    methods: {
      handleSizeChange(val) {
        this.PageSize = val
        this.currentPage = 1
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        this.currentPage = val
        console.log(`当前页: ${val}`);
      },
      getReport() {
        const path = 'http://127.0.0.1:5000/loadreport';
        axios.get(path).then(res => {
          console.log(res.data)
          this.reportTable = res.data;
          this.total = res.data.length
        }).catch(error => {
          console.error(error);
        });
      },
      handleReportDelete(index, row) {
        var filename = row['filename'];
        let formData = new FormData();
        formData.append('filename', filename);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/delreport', formData, config).then(function(response) {
          if (response.data === 'success') {
            that.getReport()
            that.$notify({
              title: '成功',
              message: filename + ' 移除成功!',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      reportDownload(index, row) {
        var filename = row['filename'];
        console.log(filename)
        console.log(index)
        var current_index = (this.currentPage - 1) * this.PageSize + index
        console.log(this.reportTable[current_index]['url'])
        window.open(this.reportTable[current_index]['url'] + '?response-content-type=application/octet-stream');
      }
    },
    created() {
      this.getReport()
    },
  }
</script>
