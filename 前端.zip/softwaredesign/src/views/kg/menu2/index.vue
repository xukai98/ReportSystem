<template>
  <div id="app" style="padding: 30px;">
    <div id="cy"></div>
  </div>
</template>
<script>
  import $ from 'jquery'
  import cytoscape from 'cytoscape'
  export default {
    data() {

    },
    methods:{

    },
    created() {
      $(function(){
        $.get('http://127.0.0.1:5000/graph', function(result) {
          const cy = cytoscape({
            container: document.getElementById('cy'),
            style: [
              { selector: 'node[label = "原因"]',
                style: {'width': '20px', 'height': '20px', 'background-color': '#87CEFA', 'label': 'data(name)'}
              },
              { selector: 'node[label = "结果"]',
                style: {'width': '20px', 'height': '20px', 'background-color': '#3cb371', 'label': 'data(name)'}
              },
              {
                selector: 'edge',
                css: {
                  'width': 1,
                  'line-color': '#FFFF00',
                  'target-arrow-color': '#87CEFA',
                  'target-arrow-shape': 'triangle',
                  'curve-style': 'bezier',
                  'content': 'data(relationship)',
                }
              }
            ],
            layout: { name: 'cose'},
            elements: result.elements
          });
          cy.nodes().style({"font-size": 5});
          cy.edges().style({"font-size": 5});
        }, 'json');
      });
    }
  }

</script>
<style>
  #cy {
    border-radius: 25px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
    margin: 0 auto;
    height: auto;
    min-height: 650px;
    width: 95%;
    background-color: #F5FFFA;
  }
</style>
