<template>
  <div>
    <div class="block">
      <el-row style="padding: 80px;" :gutter="20">
        <el-col :span="12" :offset="6">
          <div class="grid-content bg-purple">
            <el-date-picker value-format="yyyy-MM-dd HH:mm:ss" style="width: 65%;" v-model="value2" type="datetimerange"
              align="right" start-placeholder="开始日期" end-placeholder="结束日期" :default-time="['24:00:00', '06:00:00']">
            </el-date-picker>
            <el-input v-model="taskname" style="width: 15%;" placeholder="任务名称"></el-input>
            <el-button style="width: 20%;" type="primary" @click='timer()'>发布定时任务</el-button>
          </div>
        </el-col>
      </el-row>
      <el-table id="extract"
        :data="tableData.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.relation.toLowerCase().includes(search.toLowerCase()))"
        border style="width: 100%;" :header-cell-style="{'text-align':'center'}" :cell-style="{'text-align':'center'}">
        <el-table-column prop="name" label="任务名称">
        </el-table-column>
        <el-table-column prop="starttime" label="开始时间">
        </el-table-column>
        <el-table-column prop="endtime" label="结束时间">
        </el-table-column>
        <el-table-column prop="taskstatus" label="状态">
        </el-table-column>
        <el-table-column align="right">
          <template slot="header" slot-scope="scope">
            <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="taskstart(scope.$index, scope.row)">开始</el-button>
            <el-button type="success" size="mini" @click="taskpause(scope.$index, scope.row)">暂停</el-button>
            <el-button type="danger" size="mini" @click="taskdel(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block" align="center" style="margin-top: 10px;">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
          :page-sizes="pageSizes" :page-size="PageSize" layout="total, sizes, prev, pager, next, jumper" :total=total>
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import Vue from 'vue'
  export default {
    data() {
      return {
        taskname: '',
        value2: '',
        currentPage: 1,
        total: 0,
        pageSizes: [1, 2, 3, 5],
        PageSize: 5,
        newswebsite: 'http://news.carnoc.com/list/564/564791.html',
        tableData: [{
          name: '新闻采集',
          starttime: '2021-07-12 00:00:00',
          endtime: '2021-07-13 06:00:00',
          taskstatus: < el-tag type = "danger" > 暂停中 < /el-tag>
        }],
        search: ''
      };
    },
    methods: {
      handleSizeChange(val) {
        this.PageSize = val
        this.currentPage = 1
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        this.currentPage = val
        console.log(`当前页: ${val}`);
      },
      timer() {
        var list = {
          name: this.taskname,
          starttime: (this.value2)[0],
          endtime: (this.value2)[1],
          taskstatus: < el-tag type = "success" > 运行中 < /el-tag>
        }
        this.tableData.push(list)
        this.total = this.tableData.length
        console.log(this.tableData)
      },
      taskstart(index, row) {
        console.log(index)
        console.log(row)
        row['taskstatus'] = < el-tag type = "success" > 运行中 < /el-tag>
      },
      taskpause(index, row) {
        row['taskstatus'] = < el-tag type = "danger" > 暂停中 < /el-tag>
      },
      taskdel(index, row) {
        //index从0开始，如果不是从0开始就需要index-1传入splice，，用于删除数组第i个元素
        this.tableData.splice(index, 1)
      }
    },
    created() {
      this.total = this.tableData.length
    }
  }
</script>

<style>
  .el-row {
    margin-bottom: 20px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .el-col {
    border-radius: 4px;
  }

  .bg-purple-dark {
    background: #99a9bf;
  }

  .bg-purple {
    background: #ffffff;
  }

  .bg-purple-light {
    background: #e5e9f2;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }

  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }

  #extract {
    border-radius: 15px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  }
</style>
