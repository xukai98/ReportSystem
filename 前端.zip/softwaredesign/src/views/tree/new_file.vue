<template>
  <div class="hello">
    <h1>This is a show file page</h1>
    <h3>导入文件：<input type="file" name="file" @change="showFile($event)" /> </h3><br>
    <textarea v-model="input_text" name="" cols="100" rows="20" placeholder="输入……"></textarea><br><br>
      <iframe :src=url2 style="width: 100%;height: 650px;"></iframe>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        currentPage: 0, // pdf文件页码
        pageCount: 0, // pdf文件总页数
        fileType: 'pdf', // 文件类型
        src: '', // pdf文件地址
        input_text: '',
        url1: 'http://47.104.21.26/xukai/测试文档.pdf',
        url2:'file:///localhost/D:/workspace/pycharm-workspace/SoftwareDesignFlask/file_template/测试文档1.pdf'
      }
    },
    methods: {
      showFile(input) {
        //支持chrome IE10
        if (window.FileReader) {
          var file = input.target.files[0];
          var reader = new FileReader();
          reader.onload = ((event) => {
            //显示文件
            this.input_text = event.target.result;
            console.log(event.target.result)
          })
          console.info(file)
          console.info(reader);
          reader.readAsText(file);
        } else {
          alert("FileReader Not supported by your browser!");
        }
      }
    }
  }
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  h3 {
    margin: 40px 0 0;
  }

  ul {
    list-style-type: none;
    padding: 0;
  }

  li {
    display: inline-block;
    margin: 0 10px;
  }

  a {
    color: #42b983;
  }
</style>
