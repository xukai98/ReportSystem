<template>
  <div>
    <el-tabs style="margin: 5px;" v-model="activeName" type="card" @tab-click="tabClick">
      <el-tab-pane label="上传数据源" name="first">
        <!-- Form -->
        <div align="center" style="margin: 15px;">
          <el-button type="primary" @click="dialogFormVisible = true"><i class="el-icon-upload">上传数据源</i></el-button>
        </div>
        <!-- 上传数据源弹出的对话框 -->
        <el-dialog title="数据源详情" :visible.sync="dialogFormVisible">
          <el-form :model="form">
            <el-form-item label="数据源描述" :label-width="formLabelWidth">
              <el-input v-model="form.name" autocomplete="off"></el-input>
            </el-form-item>
          </el-form>
          <div style="text-align: center;" slot="footer" class="dialog-footer">
            <el-upload class="upload-demo" ref="upload" action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview" :on-remove="handleRemove" :file-list="dataSourceTable" :auto-upload="false">
              <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
              <el-button style="margin-left: 10px;" size="small" type="success" @click="uploadData">上传到服务器</el-button>
            </el-upload>
          </div>
        </el-dialog>
        <!-- 数据源显示的列表 -->
        <div style="padding: 15px;" align="center">
          <el-table
            :data="dataSourceTable.filter(data => !search || data.template.toLowerCase().includes(search.toLowerCase()))"
            style="width: 100%">
            <el-table-column fixed prop="index" label="编号" width="100px">
            </el-table-column>
            <el-table-column prop="date" sortable label="上传日期">
            </el-table-column>
            <el-table-column prop="label" label="标签">
            </el-table-column>
            <el-table-column prop="name" label="数据源">
            </el-table-column>
            <el-table-column align="right">
              <template slot="header" slot-scope="scope">
                <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
              </template>
              <template slot-scope="scope">
                <el-button size="mini" @click="handleView(scope.$index, scope.row)"><i class="el-icon-view"></i>预览</el-button>
                <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)"><i class="el-icon-delete"></i>删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-tab-pane>
      <el-tab-pane label="选择报告模板" name="second">
        <!-- 选择报告模板 -->
        <div style="margin: 15px;" align="center">
          <el-table
            :data="templateTable.filter(data => !search || data.template.toLowerCase().includes(search.toLowerCase()))"
            style="width: 100%">
            <el-table-column fixed prop="index" label="编号" width="100px">
            </el-table-column>
            <el-table-column prop="date" sortable label="日期">
            </el-table-column>
            <el-table-column prop="url" label="路径">
            </el-table-column>
            </el-table-column>
            <el-table-column prop="template" label="模板名称">
            </el-table-column>
            <el-table-column align="right">
              <template slot="header" slot-scope="scope">
                <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
              </template>
              <template slot-scope="scope">
                <el-button size="mini" @click="handleView(scope.$index, scope.row)">预览</el-button>
                <el-button size="mini" type="primary" @click="handleChoose(scope.$index, scope.row)">使用</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-tab-pane>
      <el-tab-pane label="报告预览" name="third">
        <!-- 报告预览 -->
        <div style="height: 100%;">
          <iframe :src="url" style="width: 100%;height: 650px;"></iframe>
        </div>
      </el-tab-pane>
      <el-tab-pane label="报告生成" name="fourth">

      </el-tab-pane>
    </el-tabs>

  </div>
</template>

<script>
  import axios from 'axios'
  import Vue from 'vue'
  export default {
    data() {
      return {
        url: 'http://qv7d268qd.hd-bkt.clouddn.com/nlp12.pdf',
        url1: 'http://106.54.170.52:8082/tts/nlp1.pdf',
        dialogFormVisible: false,
        form: {
          name: '',
          region: '',
          date1: '',
          date2: '',
          delivery: false,
          type: [],
          resource: '',
          desc: ''
        },
        formLabelWidth: '120px',
        search: '',
        activeName: 'first',
        publicPath: process.env.BASE_URL,
        //数据源上传列表
        dataSourceTable: [{
          index: '1',
          date: '2021-5-19',
          label: '国内数据',
          name: 'domestic.csv',
        }, {
          index: '2',
          date: '2021-5-18',
          label: '国际数据',
          name: 'international.csv',
        }, ],
        templateTable: [{
          index: '1',
          date: '2021-5-19',
          url: '/root',
          template: 'test.docx',
        }, {
          index: '2',
          date: '2021-5-18',
          url: '/root',
          template: 'template.docx',
        }, ]
      }
    },
    methods: {
      uploadData() {
        this.$refs.upload.submit();//应该等上传成功后再关闭对话框
        this.dialogFormVisible=false;
      },
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
      },
      tabClick(tab, event) {
        console.log(tab, event);
      },
      handleView(index, row) {
        console.log(index, row);
      },
      handleChoose(index, row) {
        console.log(index, row);
      },
      handleDelete(index, row) {
        console.log(index, row);
      },
      depprase() {
        if (this.deppraseinput == '') { //判断是否输入校验
          this.$message({
            message: '请输入语句！',
            type: 'warning'
          });
        } else {
          axios({
              method: 'post',
              url: 'http://localhost:8586/Corenlp/depprase',
              data: {
                input: this.deppraseinput
              },
              dataType: 'json',
              headers: {
                'Content-Type': 'application/json;charset=UTF-8'
              }
            }).then(response => {
              this.deppraselist = [];
              console.log(response); //返回的数据
              var s = response.data.length;
              console.log(s); //输出返回数组的长度
              var size = response.data.length;
              for (var i = 0; i < size; i++) {
                this.deppraselist.push(response.data[i]);
              }
              console.log(this.deppraselist);
            })
            .catch(function(error) {
              console.log(error);
            });
        }
      },
    }
  }
</script>

<style>
  /* 图表样式选择 */
  .time {
    font-size: 13px;
    color: #999;
  }

  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }

  .button {
    padding: 0;
    float: right;
  }

  .image {
    width: 100%;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }

  .clearfix:after {
    clear: both
  }

  /* 图表样式选择 */
</style>
