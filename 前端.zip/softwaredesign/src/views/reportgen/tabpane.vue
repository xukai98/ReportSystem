<template>
  <el-tab-pane label="景气指数">
    <!-- 选择图表样式 -->
    <div style="margin: 15px;" align="center">
      <el-row>
        <el-col style="padding: 5px;" :span="8" v-for="url in aurls" :offset="0">
          <el-card :body-style="{ padding: '5px' }">
            <img :src='`${publicPath}images/a/`+url.url' class="image">
            <div style="padding: 10px;">
              <div class="bottom clearfix">
                <el-button type="primary" icon="el-icon-check" round @click='chooseChart()'>选择{{url.type}}</el-button>
                <!-- <el-checkbox v-model="atype" :label=url.type name="type"></el-checkbox> -->
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </el-tab-pane>
  <el-tab-pane label="量价指数">
    <!-- 选择图表样式 -->
    <div style="margin: 15px;" align="center">
      <el-row>
        <el-col style="padding: 5px;" :span="8" v-for="url in burls" :offset="0">
          <el-card :body-style="{ padding: '5px' }">
            <img :src='`${publicPath}images/`+url.url' class="image">
            <div style="padding: 10px;">
              <div class="bottom clearfix">
                <el-checkbox v-model="btype" :label=url.type name="type"></el-checkbox>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </el-tab-pane>
  <el-tab-pane label="客座率指数">
    <!-- 选择图表样式 -->
    <div style="margin: 15px;" align="center">
      <el-row>
        <el-col style="padding: 5px;" :span="8" v-for="url in curls" :offset="0">
          <el-card :body-style="{ padding: '5px' }">
            <img :src='`${publicPath}images/`+url.url' class="image">
            <div style="padding: 10px;">
              <div class="bottom clearfix">
                <el-checkbox v-model="ctype" :label=url.type name="type"></el-checkbox>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </el-tab-pane>
  <el-tab-pane label="上半年民航国内旅行者特征">
    <!-- 选择图表样式 -->
    <div style="margin: 15px;" align="center">
      <el-row>
        <el-col style="padding: 5px;" :span="8" v-for="url in durls" :offset="0">
          <el-card :body-style="{ padding: '5px' }">
            <img :src='`${publicPath}images/`+url.url' class="image">
            <div style="padding: 10px;">
              <div class="bottom clearfix">
                <el-checkbox v-model="dtype" :label=url.type name="type"></el-checkbox>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </el-tab-pane>
  <el-tab-pane label="上半年民航国际旅行者特征">
    <!-- 选择图表样式 -->
    <div style="margin: 15px;" align="center">
      <el-row>
        <el-col style="padding: 5px;" :span="8" v-for="url in eurls" :offset="0">
          <el-card :body-style="{ padding: '5px' }">
            <img :src='`${publicPath}images/`+url.url' class="image">
            <div style="padding: 10px;">
              <div class="bottom clearfix">
                <el-checkbox v-model="etype" :label=url.type name="type"></el-checkbox>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </el-tab-pane>
  <el-tab-pane label="上半年节假日市场概况">
    <!-- 选择图表样式 -->
    <div style="margin: 15px;" align="center">
      <el-row>
        <el-col style="padding: 5px;" :span="8" v-for="url in furls" :offset="0">
          <el-card :body-style="{ padding: '5px' }">
            <img :src='`${publicPath}images/`+url.url' class="image">
            <div style="padding: 10px;">
              <div class="bottom clearfix">
                <el-checkbox v-model="ftype" :label=url.type name="type"></el-checkbox>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </el-tab-pane>
</template>
<el-tab-pane v-for="(item,index) in list" :key="index" :label="item.label" :name="item.name">
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="urls in item" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <img :src="`${publicPath}images/`+urls.pos+'/'+urls.url" class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart()'>选择{{url.type}}</el-button>
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
<script>
  list: [{
      label: '客座率指数',
      name: 'first',
      urls: [{
        url: '柱状图.png',
        type: '柱状图'
      }, {
        url: '折线图.png',
        type: '折线图'
      }, {
        url: '饼图.png',
        type: '混合图'
      }],
    },
    {
      label: '景气指数',
      name: 'second',
      urls: [{
        url: '柱状图.png',
        type: '柱状图'
      }, {
        url: '折线图.png',
        type: '折线图'
      }, {
        url: '饼图.png',
        type: '混合图'
      }],
    },
    {
      label: '旅客周转量',
      name: 'third',
      urls: [{
        url: '柱状图.png',
        type: '柱状图'
      }, {
        url: '折线图.png',
        type: '折线图'
      }, {
        url: '饼图.png',
        type: '混合图'
      }],
    },
    {
      label: '运输量指数',
      name: 'fourth',
      urls: [{
        url: '柱状图.png',
        type: '柱状图'
      }, {
        url: '折线图.png',
        type: '折线图'
      }, {
        url: '饼图.png',
        type: '混合图'
      }],
    },
    {
      label: '飞机日利用率指数',
      name: 'fifth',
      urls: [{
        url: '柱状图.png',
        type: '柱状图'
      }, {
        url: '折线图.png',
        type: '折线图'
      }, {
        url: '饼图.png',
        type: '混合图'
      }],
    },
    {
      label: '运载率指数',
      name: 'sixth',
      urls: [{
        url: '柱状图.png',
        type: '柱状图'
      }, {
        url: '折线图.png',
        type: '折线图'
      }, {
        url: '饼图.png',
        type: '混合图'
      }],
    }
  ],
</script>

<style>
</style>
