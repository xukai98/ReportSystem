$(function(){
  $.get('/graph', function(result) {
    const cy = cytoscape({
      container: document.getElementById('cy'),
      style: [
        { selector: 'node[label = "原因"]',
          style: {'background-color': '#87CEFA', 'label': 'data(name)'}
        },
        { selector: 'node[label = "结果"]',
          style: {'background-color': '#FFA500', 'label': 'data(date)'}
        },
        {
          selector: 'edge',
          css: {
            'width': 1,
            'line-color': 'blue',
            'target-arrow-color': 'red',
            'target-arrow-shape': 'triangle',
            'curve-style': 'bezier',
            'content': 'data(relationship)',
          }
        }
      ],
      layout: { name: 'cose'},
      elements: result.elements
    });
  }, 'json');
});