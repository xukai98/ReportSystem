#指定训练好的模型
from utils import predictor
from gne import GeneralNewsExtractor
import requests
import re
# https://github.com/kingname/GeneralNewsExtractor

url = 'http://news.carnoc.com/list/564/564791.html'
res = requests.get(url)
# res.encoding = 'utf-8'
html = res.text
extractor = GeneralNewsExtractor()
result = extractor.extract(html, noise_node_list=['//div[@class="comment-list"]'])
text = result['content']
sentences = re.split(r'。', text)
print(sentences)
for sentence in sentences:
    print(sentence)
    model = predictor("param1.param290") #加载模型
    sentence = [sentence] #输入测试样例
    model(sentence)#获取结果

