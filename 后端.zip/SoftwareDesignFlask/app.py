import py2neo
from docx.shared import Mm
from flask import Flask, jsonify, request, render_template
from flask_cors import *
import time
import os
import matplotlib.pyplot as plt
import pandas as pd
from docxtpl import DocxTemplate, InlineImage
from win32com.client import Dispatch, constants, gencache
import pythoncom
import psycopg2
import json
from qiniu import Auth, put_file, put_data
from py2neo import Graph, Node, Relationship
import requests
from gne import GeneralNewsExtractor
import re
from utils import predictor
from pyhanlp import HanLP

test_graph = Graph(
    "http://localhost:7474",
    username="neo4j",
    password="123456"
)
app = Flask(__name__)
CORS(app, supports_credentials=True)
# conn = psycopg2.connect(database="postgres",user="postgres",password="123",host="106.54.170.52",port="5433")
conn = psycopg2.connect(database="software",user="postgres",password="123",host="127.0.0.1",port="5432")
cur = conn.cursor()
template_name = ''
basepath = os.path.dirname(__file__)
prework = {}
arr = []



def createkg(node1,node2,relation):
    # 建立节点
    test_node_1 = Node("原因", name=node1)
    test_node_2 = Node("结果", name=node2)
    test_graph.create(test_node_1)
    test_graph.create(test_node_2)
    # 建立关系
    node_1_call_node_2 = Relationship(test_node_1, relation, test_node_2)
    test_graph.create(node_1_call_node_2)
    test_graph.push(test_node_1)
    test_graph.push(test_node_2)

@app.route('/importnoderelation', methods=['GET', 'POST'])
def import_node_relation():
    bpredicate = request.form.get('bpredicate')
    bsubject = request.form.get('bsubject')
    opredicate = request.form.get('opredicate')
    osubject = request.form.get('osubject')
    relation = request.form.get('relation')
    sentence = request.form.get('sentence')
    # relation = re.findall(r"\u2E80-\u9fff", relation)
    pattern = r'[\u4e00-\u9fff]+'  # 汉字正则表达式
    re_compile = re.compile(pattern)
    res = re_compile.findall(relation)
    relation = str(res[0])
    node1 = str(bpredicate+bsubject)
    node2 = str(opredicate+osubject)
    createkg(node1, node2, relation)
    return 'success'

def testgne(url):
    res = requests.get(url)
    # res.encoding = 'utf-8'
    html = res.text
    extractor = GeneralNewsExtractor()
    result = extractor.extract(html, noise_node_list=['//div[@class="comment-list"]'])
    # print(result[key])
    return result
# 解析新闻链接，加载ML模型抽取三元组 --- 开始
@app.route('/newsurl', methods=['GET','POST'])
def extract_info():
    url = request.form.get('url')
    print(url)
    result = testgne(url)
    title = result['title']
    content = result['content']
    sentences = re.split(r'。', content)
    print(title)
    print(sentences[:-1])
    triple = []
    model = predictor("param1.param290")  # 加载模型
    for i in range(len(sentences[:-1])):
        print(i)
        sentence = [sentences[i]]
        print('sentence:')
        print(sentence)
        result = model(sentence)  # 获取结果
        print(sentence[0]+'result：')
        if len((result[0])):
            res = ((result[0])[0])
            # print((((result[0])[0])[0])['type'])
            triple_dict = {}
            if len(res) == 5:
                triple_dict['bsubject'] = (res[0])['value']
                triple_dict['bpredicate'] = (res[1])['value']
                triple_dict['osubject'] = (res[2])['value']
                triple_dict['opredicate'] = (res[3])['value']
                triple_dict['relation'] = (res[4])['value']
                triple_dict['sentence'] = sentence[0]
                print(triple_dict)
                triple.append(triple_dict)
            if len(res) == 4:
                triple_dict['bsubject'] = (res[0])['value']
                triple_dict['bpredicate'] = (res[1])['value']
                triple_dict['osubject'] = (res[2])['value']
                triple_dict['opredicate'] = (res[3])['value']
                triple_dict['relation'] = '未识别出关系词'
                triple_dict['sentence'] = sentence[0]
                print(triple_dict)
                triple.append(triple_dict)
    print(triple)
    dict = {}
    dict['title'] = str(title)
    dict['content'] = sentences[:-1]
    dict['sentences'] = triple
    return jsonify(dict)
# 解析新闻链接，加载ML模型抽取三元组 --- 结束

# neo4j可视化信息获取 --- 开始
def buildNodes(nodeRecord):
    data = {"id": str(nodeRecord['id']), "label": next(iter(nodeRecord['label']))}
    data.update(nodeRecord['n'])
    print(data)
    return {"data": data}


def buildEdges(relationRecord):
    data = {"source": str(relationRecord['start_id']), "target": str(relationRecord['end_id']), "relationship": relationRecord['type']}
    print(data)
    return {"data": data}


@app.route('/graph')
def get_graph():
    nodes = list(map(buildNodes, json.loads
    (json.dumps(test_graph.run('MATCH (n) RETURN id(n) as id, labels(n) as label, n').data(), ensure_ascii=False))))
    edges = list(map(buildEdges, json.loads
    (json.dumps(test_graph.run
                ('MATCH (n1)-[r]->(n2) RETURN id(r) as id, id(n1) as start_id, id(n2) as end_id, type(r) as type, r'
                 ).data(), ensure_ascii=False))))
    return jsonify(elements = {"nodes": nodes, "edges": edges})
# neo4j可视化信息获取 --- 结束


@app.route('/getactive', methods=['GET','POST'])
def init_activeflag():
    sql = "SELECT step FROM activeflag WHERE activeflag='true'"
    cur.execute(sql)
    active = cur.fetchone()[0]
    conn.commit()
    return jsonify(active)

@app.route('/updateactive', methods=['GET','POST'])
def update_activeflag():
    activeflag1 = request.form.get("activeflag1")
    step1 = request.form.get("step1")
    activeflag2 = request.form.get("activeflag2")
    step2 = request.form.get("step2")
    sql1 = "UPDATE activeflag SET activeflag = '" + activeflag1 + "' WHERE step = '" + step1 + "' "
    sql2 = "UPDATE activeflag SET activeflag = '" + activeflag2 + "' WHERE step = '" + step2 + "'"
    cur.execute(sql1)
    cur.execute(sql2)
    print(sql1)
    print(sql2)
    conn.commit()
    return jsonify('success')

@app.route('/cleardict', methods=['GET','POST'])
def clear_dict_update_activeflag():
    activeflag1 = request.form.get("activeflag1")
    step1 = request.form.get("step1")
    activeflag2 = request.form.get("activeflag2")
    step2 = request.form.get("step2")
    sql1 = "UPDATE activeflag SET activeflag = '" + activeflag1 + "' WHERE step = '" + step1 + "' "
    sql2 = "UPDATE activeflag SET activeflag = '" + activeflag2 + "' WHERE step = '" + step2 + "'"
    cur.execute(sql1)
    cur.execute(sql2)
    print(sql1)
    print(sql2)
    conn.commit()
    clear_dict()
    return jsonify('success')
# 保存报告信息
def insert_report(createdate,personname,phonenum,filename,filesize,url):
    sql = "INSERT INTO report(createdate,personname, phonenum, filename, filesize, url) VALUES ('" + createdate + "','" + personname + "', '" + phonenum + "', '" + filename + "', '" + filesize + "', '" + url + "')"
    print(sql)
    cur.execute(sql)
    conn.commit()
    print('保存成功')
# 保存模板信息
def insert_template(uploaddate,description,filename,filesize,filepath):
    sql = "INSERT INTO template(uploaddate,description, filename, filesize, filepath) VALUES ('" + uploaddate + "','" + description + "', '" + filename + "', '" + filesize + "', '" + filepath + "')"
    print(sql)
    cur.execute(sql)
    conn.commit()
    print('保存成功')
# 保存数据源信息
def insert_datasource(uploaddate,description,filename,filesize,filepath):
    sql = "INSERT INTO datasource(uploaddate,description, filename, filesize, filepath) VALUES ('" + uploaddate + "','" + description + "', '" + filename + "', '" + filesize + "', '" + filepath + "')"
    print(sql)
    cur.execute(sql)
    conn.commit()
    print('保存成功')
# docx转pdf用于预览
def doc2pdf(input, output):
    w = Dispatch('Word.Application')
    try:
        # 打开文件
        doc = w.Documents.Open(input, ReadOnly=1)
        # 转换文件
        doc.ExportAsFixedFormat(output, constants.wdExportFormatPDF,
                                Item=constants.wdExportDocumentWithMarkup,
                                CreateBookmarks=constants.wdExportCreateHeadingBookmarks)
        return True
    except:
        return False
    finally:
        w.Quit(constants.wdDoNotSaveChanges)
def GenerateSupport():
    gencache.EnsureModule('{00020905-0000-0000-C000-000000000046}', 0, 8, 4)
# B->KB转换
def computefilesize(filesize):
    filesize = int(filesize)
    filesize = int((filesize + 1023) / 1024)#B转为KB
    filesize = str(filesize)+'KB'
    return filesize
# 获取格式化时间
def getdate():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
# 用于给文件命名
def getdate2name():
    return time.strftime("%Y%m%d%H%M%S", time.localtime())
@app.route('/reportgen', methods=['GET'])
def test():
    return 'Hello World!'

# 上传数据源文件，获取文件信息，保存文件
@app.route("/updatasource", methods=["POST"])
def upload_datasource():
    description = request.form.get("desc")
    fileObj = request.files.get("file")
    filename = request.form.get('filename')
    filesize = request.form.get('filesize')
    data = dict(filename=filename,filesize=computefilesize(filesize),description=description,date=getdate())
    res_data = jsonify(data)
    basepath = os.path.dirname(__file__)
    upload_path = os.path.abspath(os.path.join(basepath, 'data_source', filename))  # 将路径转换为绝对路径
    fileObj.save(upload_path)
    insert_datasource(getdate(), description, filename, computefilesize(filesize), upload_path)
    return res_data
# 上传报告模板
@app.route("/uptemplate", methods=["POST"])
def upload_template():
    description = request.form.get("desc")
    fileObj = request.files.get("file")
    filename = request.form.get('filename')
    filesize = request.form.get('filesize')
    basepath = os.path.dirname(__file__)
    # vue_path = r'F:\software-design\software-design\public'
    upload_flask_path = os.path.abspath(os.path.join(basepath, 'file_template', filename))  # 将路径转换为绝对路径
    # upload_vue_path = os.path.abspath(os.path.join(vue_path, 'preview_files', filename[:-4] + 'pdf'))
    fileObj.save(upload_flask_path)
    input = upload_flask_path
    output = os.path.abspath(os.path.join(basepath, 'template_view', filename[:-4] + 'pdf'))
    pythoncom.CoInitialize()
    GenerateSupport()
    rc = doc2pdf(input, output)
    if rc:
        print('转换成功')
        file = open(output, 'rb')
        file_qiniu_name = filename[:-4] + 'pdf'
        url = upload_qiniu(file,file_qiniu_name)
    else:
        print('转换失败')
    insert_template(getdate(),description,filename,computefilesize(filesize),url)
    data = dict(filename=filename, filesize=computefilesize(filesize), description=description, date=getdate(), filepath=url)
    res_data = jsonify(data)
    return res_data
# 将数据库中存储的数据源信息返回给前端
@app.route("/loaddatasource", methods=['GET', 'POST'])
def load_data_source():
    sql = "select * from datasource"
    cur.execute(sql)
    result = cur.fetchall()
    result_data = []
    for data in result:
        data_str = {}
        data_str["date"] = data[0]
        data_str["description"] = data[1]
        data_str["filename"] = data[2]
        data_str["filesize"] = data[3]
        data_str["filepath"] = data[4]
        result_data.append(data_str)
    print(result_data)
    return jsonify(result_data)
# 将数据库中存储的模板信息返回给前端
@app.route("/loadtemplate", methods=['GET', 'POST'])
def load_template():
    sql = "select * from template"
    cur.execute(sql)
    result = cur.fetchall()
    result_data = []
    for data in result:
        data_str = {}
        data_str["date"] = data[0]
        data_str["description"] = data[1]
        data_str["filename"] = data[2]
        data_str["filesize"] = data[3]
        data_str["filepath"] = data[4]
        result_data.append(data_str)
    print(result_data)
    return jsonify(result_data)
# 将数据库中存储的报告信息返回给前端
@app.route("/loadreport", methods=['GET', 'POST'])
def load_report():
    sql = "select * from report"
    cur.execute(sql)
    result = cur.fetchall()
    result_data = []
    for data in result:
        data_str = {}
        data_str["date"] = data[0]
        data_str["name"] = data[1]
        data_str["phonenum"] = data[2]
        data_str["filename"] = data[3]
        data_str["filesize"] = data[4]
        data_str["url"] = data[5]
        result_data.append(data_str)
    print(result_data)
    return jsonify(result_data)


# 删除报告模板
@app.route("/deltemplate", methods=['POST', 'GET'])
def del_template():
    filename = request.form.get('filename')
    sql = "DELETE FROM template WHERE filename = '" + filename + "'"
    cur.execute(sql)
    conn.commit()
    os.remove("file_template/"+filename)
    return 'success'
# 删除报告
@app.route("/delreport", methods=['POST', 'GET'])
def del_report():
    filename = request.form.get('filename')
    sql = "DELETE FROM report WHERE filename = '" + filename + "'"
    cur.execute(sql)
    conn.commit()
    os.remove("report/" + filename)
    return 'success'
# 删除数据源
@app.route("/deldatasource", methods=['POST', 'GET'])
def del_data_source():
    filename = request.form.get('filename')
    sql = "DELETE FROM datasource WHERE filename = '" + filename + "'"
    cur.execute(sql)
    conn.commit()
    os.remove('data_source/'+filename)
    return 'success'

# 对csv数据进行解析，生成三种类型的图表
@app.route("/usedatasource", methods=['POST', 'GET'])
def use_datasource():
    filename = request.form.get('filename')
    plot1(filename, clas="国内航线", piccls=1)
    plot1(filename, clas="国内航线", piccls=2)
    plot1(filename, clas="国内航线", piccls=3)
    return 'success'


# 保存前端选择的图表样式
@app.route("/choosecharttype", methods=['POST', 'GET'])
def choose_chart_type():
    dict = {}
    print(dict)
    dict.clear()
    template_name = request.form.get('templatename')
    print(template_name)
    tabname = request.form.get('tabname')
    type = request.form.get('type')
    # 把字典内所有key为tabname的都设为新传入的值了
    dict['tabname'] = tabname
    dict['type'] = type
    arr.append(dict)
    prework[template_name] = arr
    basepath = os.path.dirname(__file__)
    dict_path = os.path.abspath(os.path.join(basepath, 'dict2.json'))
    jsobj = json.dumps(prework,separators=(',', ':'),ensure_ascii=False,indent=4)
    fileObject = open(dict_path,'w',encoding='utf-8')
    fileObject.write(jsobj)
    print(prework)
    return 'success'

# 下载生成的报告
# 根据文件名查询数据库存储的文件url,然后返回前端下载
@app.route('/downloadreport', methods=['GET','POST'])
def download_report():
    filename = request.form.get("filename")
    sql = "SELECT url FROM report WHERE filename='" + filename + "'"
    cur.execute(sql)
    url = cur.fetchone()[0]
    conn.commit()
    return url
# 点击下一步进入的报告预览
@app.route("/yulan", methods=['POST','GET'])
def yulan():
    activeflag1 = request.form.get("activeflag1")
    step1 = request.form.get("step1")
    activeflag2 = request.form.get("activeflag2")
    step2 = request.form.get("step2")
    sql1 = "UPDATE activeflag SET activeflag = '" + activeflag1 + "' WHERE step = '" + step1 + "' "
    sql2 = "UPDATE activeflag SET activeflag = '" + activeflag2 + "' WHERE step = '" + step2 + "'"
    cur.execute(sql1)
    cur.execute(sql2)
    print(sql1)
    print(sql2)
    conn.commit()
    with open('dict2.json', 'r', encoding='utf8')as fp:
        json_data = json.load(fp)
        for key in json_data:
            print("key:"+key)
            template_name = key
            template_path = os.path.abspath(os.path.join(basepath, 'file_template', template_name))  # 将路径转换为绝对路径
            doc = DocxTemplate(template_path)
            genreportname = getdate2name() + '.docx'
            image1_path = os.path.abspath(
                os.path.join(basepath, 'images/景气指数/', json_data[template_name][0].get('type') + '.png'))
            image2_path = os.path.abspath(
                os.path.join(basepath, 'images/旅客运输量指数/', json_data[template_name][1].get('type') + '.png'))
            image3_path = os.path.abspath(
                os.path.join(basepath, 'images/客座率指数/', json_data[template_name][2].get('type') + '.png'))
            image4_path = os.path.abspath(
                os.path.join(basepath, 'images/运载率指数/', json_data[template_name][3].get('type') + '.png'))
            image5_path = os.path.abspath(
                os.path.join(basepath, 'images/飞机日利用率指数/', json_data[template_name][4].get('type') + '.png'))
            image6_path = os.path.abspath(
                os.path.join(basepath, 'images/旅客周转量指数/', json_data[template_name][5].get('type') + '.png'))
            print(image1_path + '和' + image2_path+'和'+image3_path)
            num = []
            jingqi = pd.read_csv("data_source/景气指数.csv")
            yunshu = pd.read_csv("data_source/旅客运输量指数.csv")
            zhouzhuan = pd.read_csv("data_source/旅客周转量指数.csv")
            rrate = pd.read_csv("data_source/飞机日利用率指数.csv")
            krate = pd.read_csv("data_source/客座率指数.csv")
            zrate = pd.read_csv("data_source/运载率指数.csv")
            # 1 2
            num.append('129')
            num.append('114')
            # 3 4
            num.append('上升')
            temp = yunshu.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(float(temp.mean()), 2)))
            # 5
            temp = yunshu.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 6
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(float(temp.mean()), 2)))
            # 7
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 8
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 9
            temp = yunshu.loc[yunshu['航线类型'] == '港澳台航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(float(temp.mean()), 2)))
            # 10
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 11
            temp = krate.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)
            # 12
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 13
            temp = krate.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 14 15 16
            temp = zrate.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)))
            temp = krate.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            # 17 18 19
            temp = rrate.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)

            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)))
            temp = krate.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 20 21 22
            temp = zhouzhuan.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 23 24
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            # 25 26 27
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 28 29
            temp = zhouzhuan.loc[yunshu['航线类型'] == '港澳台航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[yunshu['航线类型'] == '港澳台航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # MATCH p=()-[r:`导致`]->() RETURN p LIMIT 25
            query_nlpkg1 = "MATCH (n:`结果`{name:'国内民航稳步上升'})<-[r:`导致`]-(nlpkg1:`原因`) RETURN nlpkg1"
            query_nlpkg2 = "MATCH (n:`结果`{name:'国际民航增速放缓'})<-[r:`导致`]-(nlpkg2:`原因`) RETURN nlpkg2"
            # query = 'MATCH (a)-[r:`导致`]->(国际民航增速放缓) RETURN a'
            # 执行CQL语句，并返回Cursor，通过循环调用返回Record
            nlpkg1 = test_graph.run(query_nlpkg1)
            nlpkg2 = test_graph.run(query_nlpkg2)
            # print(((result.data()[0])['end'])['date'])
            nlpkg1 = nlpkg1.to_subgraph()
            nlpkg2 = nlpkg2.to_subgraph()
            print(nlpkg1['date'] + nlpkg1['name'])
            print(nlpkg2['date'] + nlpkg2['name'])
            nlpkg1 = nlpkg1['date'] + nlpkg1['name']
            nlpkg2 = nlpkg2['date'] + nlpkg2['name']
            context = {
                'nlpkg1': nlpkg1,
                'nlpkg2': nlpkg2,
                'num1': num[0],
                'num2': num[1],
                'num3': num[2],
                'num4': num[3],
                'num5': num[4],
                'num6': num[5],
                'num7': num[6],
                'num8': num[7],
                'num9': num[8],
                'num10': num[9],
                'num11': num[10],
                'num12': num[11],
                'num13': num[12],
                'num14': num[13],
                'num15': num[14],
                'num16': num[15],
                'num17': num[16],
                'num18': num[17],
                'num19': num[18],
                'num20': num[19],
                'num21': num[20],
                'num22': num[21],
                'num23': num[22],
                'num24': num[23],
                'num25': num[24],
                'num26': num[25],
                'num27': num[26],
                'num28': num[27],
                'num29': num[28],
                'image1': InlineImage(doc, image1_path, width=Mm(140)),
                'image2': InlineImage(doc, image2_path, width=Mm(140)),
                'image3': InlineImage(doc, image3_path, width=Mm(140)),
                'image4': InlineImage(doc, image4_path, width=Mm(140)),
                'image5': InlineImage(doc, image5_path, width=Mm(140)),
                'image6': InlineImage(doc, image6_path, width=Mm(140)),
            }
            doc.render(context)
            report_path = os.path.abspath(os.path.join(basepath, 'report', genreportname))
            doc.save(report_path)
            input = report_path
            output = os.path.abspath(os.path.join(basepath, 'report_view', genreportname[:-4] + 'pdf'))
            pythoncom.CoInitialize()
            GenerateSupport()
            rc = doc2pdf(input, output)
            if rc:
                print('转换成功')
                pre_report_name = '1' + genreportname[:-4] + 'pdf'
                file = open(output, 'rb')
                url = upload_qiniu(file, pre_report_name)

                return url
                # arr.clear()

            else:
                print('转换失败')
                return 'failure'


def get_FileSize(filePath):
    fsize = os.path.getsize(filePath)
    fsize = fsize / float(1024 * 1024)

    return round(fsize, 2)
# 画图函数
def plot1(filename, clas="国内航线", piccls=1):
    # 画客座率，飞机日利用率，景气指数，载运率的时候clas随便指定
    # piccls=1 :折线图  piccls=2 :柱状图  piccls=3 :折线图+折线图
    csv_path = os.path.abspath(os.path.join(basepath, 'data_source', filename))
    print(csv_path)
    data = pd.read_csv(csv_path)
    print(data)
    if filename == "旅客运输量指数.csv" or filename == "旅客周转量指数.csv":
        data = data.loc[data['航线类型'] == clas]
        data = data.loc[:, ['实际完成数']]

    if filename == "景气指数.csv":
        data = data.loc[data['起飞年'] == 2015]
        data = data.loc[:, ['景气指数']]

    if filename == "飞机日利用率指数.csv" or filename == "客座率指数.csv" or filename == "运载率指数.csv":
        data = data.loc[:, ['实际完成数']]
    data = pd.np.array(data)
    data = data.reshape(data.shape[0])
    plt.figure(figsize=(30, 15))
    image_name = ''
    if piccls == 1:
        plt.plot(data, marker='o', markersize='20', lw=5)
        image_name = '折线图.png'
    if piccls == 2:
        plt.bar(range(data.shape[0]), height=data, facecolor='#ff9999', width=0.5)
        image_name = '柱状图.png'
    if piccls == 3:
        plt.plot(data, marker='o', markersize='20', lw=5)
        plt.bar(range(data.shape[0]), height=data, facecolor='#ff9999', width=0.5)
        image_name = '混合图.png'
    plt.xlabel("time")
    plt.xticks([])
    plt.legend(loc='upper right')
    # 保存图片
    img_path = os.path.abspath(os.path.join(basepath, 'images/'+filename[:-4], image_name))
    plt.savefig(img_path)
    file = open(img_path, 'rb')
    url = upload_qiniu(file, filename[:-4]+image_name)
    print(url)
    plt.show()

@app.route("/cleardict", methods=['GET','POST'])
def clear_dict():
    os.remove("dict2.json")
    print("dict初始化成功")
# 前端传模板到后端文件夹内，前端点击使用传递模板名称给后端，然后传递生成报告的标题
# https://www.jianshu.com/p/465516750da6
@app.route("/genreport", methods=['GET','POST'])
def generate_report():
    basepath = os.path.dirname(__file__)
    with open('dict2.json', 'r', encoding='utf8')as fp:
        json_data = json.load(fp)
        for key in json_data:
            print("key:"+key)
            template_name = key
            genreportname = request.form.get('genreportname')+'.docx'
            name = request.form.get('name')
            phonenum = request.form.get('phonenum')
            print(genreportname+name+phonenum)
            template_path = os.path.abspath(os.path.join(basepath, 'file_template', template_name))  # 将路径转换为绝对路径
            doc = DocxTemplate(template_path)
            image1_path = os.path.abspath(
                os.path.join(basepath, 'images/景气指数/', json_data[template_name][0].get('type') + '.png'))
            image2_path = os.path.abspath(
                os.path.join(basepath, 'images/旅客运输量指数/', json_data[template_name][1].get('type') + '.png'))
            image3_path = os.path.abspath(
                os.path.join(basepath, 'images/客座率指数/', json_data[template_name][2].get('type') + '.png'))
            image4_path = os.path.abspath(
                os.path.join(basepath, 'images/运载率指数/', json_data[template_name][3].get('type') + '.png'))
            image5_path = os.path.abspath(
                os.path.join(basepath, 'images/飞机日利用率指数/', json_data[template_name][4].get('type') + '.png'))
            image6_path = os.path.abspath(
                os.path.join(basepath, 'images/旅客周转量指数/', json_data[template_name][5].get('type') + '.png'))
            num = []
            jingqi = pd.read_csv("data_source/景气指数.csv")
            yunshu = pd.read_csv("data_source/旅客运输量指数.csv")
            zhouzhuan = pd.read_csv("data_source/旅客周转量指数.csv")
            rrate = pd.read_csv("data_source/飞机日利用率指数.csv")
            krate = pd.read_csv("data_source/客座率指数.csv")
            zrate = pd.read_csv("data_source/运载率指数.csv")
            # 1 2
            num.append('129')
            num.append('114')
            # 3 4
            num.append('上升')
            temp = yunshu.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(float(temp.mean()), 2)))
            # 5
            temp = yunshu.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 6
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(float(temp.mean()), 2)))
            # 7
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 8
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 9
            temp = yunshu.loc[yunshu['航线类型'] == '港澳台航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(float(temp.mean()), 2)))
            # 10
            temp = yunshu.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 11
            temp = krate.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)
            # 12
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # 13
            temp = krate.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 14 15 16
            temp = zrate.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)))
            temp = krate.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            # 17 18 19
            temp = rrate.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)

            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)))
            temp = krate.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 20 21 22
            temp = zhouzhuan.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a)
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 23 24
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国内航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            # 25 26 27
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            temp = zhouzhuan.loc[yunshu['航线类型'] == '国际航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(float(temp.max())))
            # 28 29
            temp = zhouzhuan.loc[yunshu['航线类型'] == '港澳台航线']
            temp = temp.loc[:, ["实际完成数"]]
            num.append(str(round(abs(float(temp.mean())), 2)))
            temp = zhouzhuan.loc[yunshu['航线类型'] == '港澳台航线']
            temp = temp.loc[:, ["比上年同期增长%"]]
            if float(temp.mean()) > 0:
                a = "上升"
            else:
                a = "下降"
            num.append(a + str(round(abs(float(temp.mean())), 2)) + "%")
            # MATCH p=()-[r:`导致`]->() RETURN p LIMIT 25
            query_nlpkg1 = "MATCH (n:`结果`{name:'国内民航稳步上升'})<-[r:`导致`]-(nlpkg1:`原因`) RETURN nlpkg1"
            query_nlpkg2 = "MATCH (n:`结果`{name:'国际民航增速放缓'})<-[r:`导致`]-(nlpkg2:`原因`) RETURN nlpkg2"
            # query = 'MATCH (a)-[r:`导致`]->(国际民航增速放缓) RETURN a'
            # 执行CQL语句，并返回Cursor，通过循环调用返回Record
            nlpkg1 = test_graph.run(query_nlpkg1)
            nlpkg2 = test_graph.run(query_nlpkg2)
            # print(((result.data()[0])['end'])['date'])
            nlpkg1 = nlpkg1.to_subgraph()
            nlpkg2 = nlpkg2.to_subgraph()
            print(nlpkg1['date'] + nlpkg1['name'])
            print(nlpkg2['date'] + nlpkg2['name'])
            nlpkg1 = nlpkg1['date'] + nlpkg1['name']
            nlpkg2 = nlpkg2['date'] + nlpkg2['name']
            context = {
                'nlpkg1': nlpkg1,
                'nlpkg2': nlpkg2,
                'num1': num[0],
                'num2': num[1],
                'num3': num[2],
                'num4': num[3],
                'num5': num[4],
                'num6': num[5],
                'num7': num[6],
                'num8': num[7],
                'num9': num[8],
                'num10': num[9],
                'num11': num[10],
                'num12': num[11],
                'num13': num[12],
                'num14': num[13],
                'num15': num[14],
                'num16': num[15],
                'num17': num[16],
                'num18': num[17],
                'num19': num[18],
                'num20': num[19],
                'num21': num[20],
                'num22': num[21],
                'num23': num[22],
                'num24': num[23],
                'num25': num[24],
                'num26': num[25],
                'num27': num[26],
                'num28': num[27],
                'num29': num[28],
                'image1': InlineImage(doc, image1_path, width=Mm(140)),
                'image2': InlineImage(doc, image2_path, width=Mm(140)),
                'image3': InlineImage(doc, image3_path, width=Mm(140)),
                'image4': InlineImage(doc, image4_path, width=Mm(140)),
                'image5': InlineImage(doc, image5_path, width=Mm(140)),
                'image6': InlineImage(doc, image6_path, width=Mm(140)),
            }
            doc.render(context)
            report_path = os.path.abspath(os.path.join(basepath, 'report', genreportname))
            doc.save(report_path)
            file = open(report_path, 'rb')
            url = upload_qiniu(file, genreportname)
            size = get_FileSize(report_path)
            print("文件大小：%.2f MB"%(size))
            insert_report(getdate(), name, phonenum, genreportname, str(size)+'MB', url)
            return 'success'

# 把文件上传到七牛云，返回url
def upload_qiniu(file,filename):
    # fp = request.files.get("file")
    fp = file
    file_name = filename
    ak = "AwtR-0_uTaXxwrJZCrAS5N3mUh-zX7suVJ43FKAq"
    sk = "s6oRHIqisAVADW1FigJCfhmqce6I8ncScDe9rTGZ"
    q = Auth(ak, sk)
    bucket_name = "ruanjianbei"
    key = file_name
    token = q.upload_token(bucket_name, key, 3600)
    ret, info = put_data(token, key, data=fp.read())
    if info.status_code == 200:
        file_url = "http://qv7d268qd.hd-bkt.clouddn.com/" + ret.get("key")
        print("文件成功保存到七牛云，访问链接："+file_url)
        return file_url


# 因果关系推理图谱构建
@app.route('/kgbuild', methods=['GET','POST'])
def kg_build():
    pass


if __name__ == '__main__':
    app.jinja_env.auto_reload = True
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.run(host='0.0.0.0',debug=True)
