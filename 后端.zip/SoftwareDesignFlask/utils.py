from paddle.io import IterableDataset
import pickle
import os
import numpy as np
from ernie.tokenizing_ernie import ErnieTokenizer
import paddle
import paddle.nn as nn
from ErnieSEG import ErnieSeg
import time

class casualdata(IterableDataset):
    def __init__(self,folder_path,batchsize=12,shuffle=True):
        super(casualdata,self).__init__()
        self.bachsize = batchsize
        self.path = folder_path
        self.tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
        self.pth_path  = [os.path.join(self.path,p) for p in os.listdir(self.path)] #文件名列表
        self.shuffle = shuffle

    def getAttmask(self,mask,ann):
        for pair in ann:
            p = pair[pair!=-1]
            if len(p) != 0:
                mask[np.min(p)+1:np.max(p)+2] = 1
        return mask
    
    def getRgmask(self,mask,ann):
        for pair in ann:
            for ind,box in enumerate(pair):
                if box[0] == -1:
                    continue
                if ind == 0 or ind == 1:
                    mask[box[0]+1:box[1]+2] = 1
                elif ind == 3 or ind == 4:
                    mask[box[0]+1:box[1]+2] = 2
        return mask

    def getClassmask(self,mask,ann):
        for pair in ann:
            for ind,box in enumerate(pair):
                if box[0] == -1:
                    continue
                if ind == 1 or ind == 4:
                    mask[box[0]+1:box[1]+2] = 2
                elif ind == 2:
                    mask[box[0]+1:box[1]+2] = 3
                elif ind == 0 or ind == 3:
                    mask[box[0]+1:box[1]+2] = 1
        return mask

    def read_data(self,path):
        load_file = open(path,"rb")
        data = pickle.load(load_file)
        load_file.close()
        token_id = self.tokenizer.encode(data["Sen"])[0]
        mask = np.zeros_like(token_id)
        att_mask = self.getAttmask(mask.copy(),data["ANN"])
        rg_mask = self.getRgmask(mask.copy(),data["ANN"])
        class_mask = self.getClassmask(mask.copy(),data["ANN"])
        return [data["Sen"],token_id,att_mask,rg_mask,class_mask]
    
    def pad_data(self,data,set_mask=False):
        max_len = np.max([len(sen) for sen in data])
        new_data = []
        maskes = []
        for sen in data:
            mask = np.zeros_like(sen)
            new_data.append(np.pad(sen,(0,max_len-len(sen)),mode="constant",constant_values=0))
            maskes.append(np.pad(mask,(0,max_len-len(mask)),mode="constant",constant_values=1))
        if set_mask:
            return np.vstack(new_data),np.vstack(maskes)
        else:
            return np.vstack(new_data),None

    def load_batch(self,pool):
        batch = []
        #读取数据
        for path in pool:
            batch.append(self.read_data(path))
        #PAD
        sentences,token_ids,att_masks,rg_masks,class_masks = zip(*batch)
        pad_token,pad_mask = self.pad_data(token_ids,set_mask=True)
        att_mask,_ = self.pad_data(att_masks)
        rg_mask,_ = self.pad_data(rg_masks)
        class_mask,_ = self.pad_data(class_masks)
        return sentences,pad_token,pad_mask,att_mask,rg_mask,class_mask

    def __iter__(self):
        pool = []
        if self.shuffle:
            np.random.shuffle(self.pth_path)
        for path in self.pth_path:
            pool.append(path)
            if len(pool) == self.bachsize:
                yield self.load_batch(pool)
                pool = []
        if len(pool) != 0:
            yield self.load_batch(pool)


class parser_layer(paddle.nn.Layer):
    def __init__(self,debug):
        super(parser_layer,self).__init__()
        self.min_len_att = 11
        self.min_len_ance = 2
        self.min_len_seq = 2
        self.class_ = [1,2]
        self.sigmoid = paddle.nn.Sigmoid()
        self.debug = debug
        self.tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
        self.min_rg_len = {1:2,2:2}
        self.min_cl_len = {1:2,2:2}
        
    
    def get_region(self,mask,class_,min_len,offset):
        r"""
        mask;array (x,class_)
        class_:list [1,2,3,...]
        min_len:dict {1:12,2:23,3:34}
        return :[{type:1,value:[]},{},{}]
        """
        sample = []
        box = {}
        length = {}
        mem = 0
        for k in class_:
            box[k] = []
            length[k] = 0
        for i in range(offset,len(mask)+offset):
            tar = mask[i-offset]
            if tar != mem:
                if mem in class_:
                    if length[mem] < min_len[mem]:
                        box[mem] = []
                        length[mem] = 0
                    else:
                        box[mem].append(i)
                        sample.append({"type":mem,"value":box[mem]})
                        box[mem] = []
                        length[mem] = 0
                mem = tar
                if tar in class_ and length[mem] == 0:
                    length[tar] += 1
                    box[tar].append(i)
            else:
                if tar in class_:
                    if i == len(mask) + offset - 1:
                        if length[mem] + 1 >= min_len[mem]:
                            box[mem].append(i+1)
                            sample.append({"type":mem,"value":box[mem]})
                    else:
                        length[mem] += 1
        return sample  
     
    def getRoi(self,mask):
        batches = []
        for i in range(mask.shape[0]):
            sample = []
            box = []
            length = 0
            for c in range(mask.shape[1]):
                if c == 0 or c == mask.shape[1] - 1:
                    if mask[i,c] >= 0.5:
                        if length == 0:
                            box.append(c)
                        elif c == mask.shape[1] -1:
                            if length >= self.min_len_att:
                                box.append(c)
                                sample.append(box)
                        length += 1
                    else:
                        if length < self.min_len_att:
                            length = 0
                            box = []
                        else:
                            length = 0
                            box.append(c)
                            sample.append(box)
                            box = []

                else:
                    if 0.125*mask[i,c-1] + 0.75*mask[i,c] + 0.125*mask[i,c+1] > 0.5:
                        if length == 0:
                            box.append(c)
                        elif c == mask.shape[1] -1:
                            if length >= self.min_len_att:
                                box.append(c)
                                sample.append(box)
                        length += 1
                    
                    else:
                        if length < self.min_len_att:
                            length = 0
                            box = []
                        else:
                            length = 0
                            box.append(c)
                            sample.append(box)
                            box = []
            batches.append(sample)
        return batches
    
    def getRg(self,mask,roi):
        min_len = {1:self.min_len_ance,2:self.min_len_seq}
        batches = []
        if not self.debug:
            mask = np.argmax(mask,axis=2)[:,:,None]
        for i in range(mask.shape[0]):
            sample = []
            roi_sample = roi[i]
            if len(roi_sample) == 0:
                batches.append(sample)
                continue
            for box in roi_sample:
                m = mask[i,box[0]:box[1],:].reshape(-1,)
                res = self.get_region(m,self.class_,self.min_rg_len,box[0])
                if len(res) != 0:
                    sample.append(res)
            batches.append(sample)
        return batches

    def getCl(self,mask,Rg,att_rois,sentences):
        id2rg = {1:"原因",2:"结果"}
        id2cl = {1:"主语",2:"谓语",3:"关系词"}
        batches = []
        if not self.debug:
            mask = np.argmax(mask,axis=2)[:,:,None]
        for i in range(mask.shape[0]):
            sen = self.tokenizer.tokenize(sentences[i])
            sample = []
            Rg_roi = Rg[i]
            att_roi = att_rois[i]
            if len(Rg_roi) == 0:
                batches.append(sample)
                continue
            for ind,roi_rg in enumerate(Rg_roi): #兴趣区域
                roi = []
                for pair in roi_rg:
                    box = pair["value"] #前因区域
                    m = mask[i,box[0]:box[1],:].reshape(-1,)
                    res = self.get_region(m,self.class_,self.min_cl_len,box[0])
                    if len(res) != 0:
                        for p in res:
                            roi.append({"type":id2rg[pair["type"]]+id2cl[p["type"]],"value":self.concat_str(sen[p["value"][0]-1:p["value"][1]-1])})
                
                m = mask[i,att_roi[ind][0]:att_roi[ind][1],:].reshape(-1,)
                res = self.get_region(m,[3],{3:2},att_roi[ind][0])
                if len(res) != 0:
                        for p in res:
                            roi.append({"type":"关系词","value":self.concat_str(sen[p["value"][0]-1:p["value"][1]-1])})
                sample.append(roi)
            batches.append(sample)
        return batches
    
    def concat_str(self,sen):
        s = ''
        for w in sen:
            s += w
        return s


    def forward(self,sentences,pre_seg,mode):
        r"""
        pre_seg Tensor(batchsize,seq_len,6)
        """
        self.debug = mode
        if not self.debug:
            pre_att_mask = self.sigmoid(pre_seg[:,:,0]).numpy()
            pre_rg_mask = pre_seg[:,:,1:4].numpy()
            pre_class_mask = pre_seg[:,:,4:].numpy()
            roi = self.getRoi(pre_att_mask) #[sample0,sample1,..],sample=[[x0,y0],[x1,y1],...]
            Rg = self.getRg(pre_rg_mask,roi) #[sample0,sample1,...],sample = [roi0,roi1,...] roi=[{type:"class",value:[x0,y0]},{}]
            Cl = self.getCl(pre_class_mask,Rg,roi,sentences) #[sample0,..] sample=[roi,] roi=[{"type":,"value":[]}]
        else:
            (pre_att_mask,pre_rg_mask,pre_class_mask) = pre_seg
            roi = self.getRoi(pre_att_mask) #[sample0,sample1,..],sample=[[x0,y0],[x1,y1],...]
            Rg = self.getRg(pre_rg_mask,roi) #[sample0,sample1,...],sample = [roi0,roi1,...] roi=[{type:"class",value:[x0,y0]},{}]
            Cl = self.getCl(pre_class_mask,Rg,roi,sentences) #[sample0,..] sample=[roi,] roi=[{"type":,"value":[]}]
        return Cl



class lossfunc(paddle.nn.Layer):
    def __init__(self):
        super(lossfunc,self).__init__()
        self.softmax = nn.functional.softmax_with_cross_entropy
        self.bce_loss = nn.functional.binary_cross_entropy_with_logits
    def forward(self,pre_seg,att_mask,rg_mask,class_mask,mask):
        pre_att_mask = pre_seg[:,:,0].unsqueeze(-1) #(batchsize,seq_len,1) Tensor float32
        pre_rg_mask = pre_seg[:,:,1:4]  #(batchsize,seq_len,3) Tensor float32
        pre_cl_mask = pre_seg[:,:,4:]  #(batchsize,seq_len,4) Tensor float32
        att_mask = paddle.to_tensor(att_mask[:,:,None],dtype="float32")
        rg_mask,class_mask = paddle.to_tensor(rg_mask[:,:,None],dtype="int64"),paddle.to_tensor(class_mask[:,:,None],dtype="int64")
        mask = paddle.to_tensor(mask[:,:,None],dtype="float32")

        rg_loss = paddle.sum(self.softmax(pre_rg_mask,rg_mask) * att_mask)
        cl_loss = paddle.sum(self.softmax(pre_cl_mask,class_mask) * att_mask)
        att_loss = self.bce_loss(pre_att_mask*mask,att_mask)
        return att_loss,rg_loss,cl_loss



class predictor(nn.Layer):
    def __init__(self,path):
        super(predictor,self).__init__()
        self.model = ErnieSeg()
        self.model.eval()
        param = paddle.load(path)
        self.model.set_state_dict(param)
        self.tokenizer = ErnieTokenizer.from_pretrained('ernie-1.0')
        self.parser = parser_layer(False)
    def forward(self,sentences):
        evl_time = []
        for ind,sen in enumerate(sentences):
            begin_t = time.time()
            input_ = self.tokenizer.encode(sen)[0].reshape(1,-1)
            input_ = paddle.to_tensor(input_,dtype="int64")
            mask = paddle.zeros_like(input_,dtype="float32")
            pre_seg = self.model(input_,mask)
            res = self.parser([sen],pre_seg,False)
            evl_time.append(time.time() - begin_t)
            # for r in res:
            #     print('#'*10)
            #     print(sen+"\n")
            #     print('*'*10)
            #     print(r)
                

        print("平均推理时间：{:.3f}".format(np.mean(evl_time)))
        # return res是后来加的，为了得到返回值
        return res
            















