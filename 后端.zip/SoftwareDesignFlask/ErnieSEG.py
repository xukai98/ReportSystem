import paddle.nn as nn
from ernie.modeling_ernie import ErnieModel
import paddle
class ErnieSeg(nn.Layer):
    r"""
    input:
    sen:src_ids Tensor(batchsize,ids) int64
    mask:Tensor(batchsize,seq_len) float32
    return：Tensor(batchsize,seq_len,6)float32 
    """
    def __init__(self,dropout=0.0):
        super(ErnieSeg,self).__init__()
        self.erniemodel = ErnieModel.from_pretrained('ernie-1.0').train()
        self.fc1 = nn.Sequential(nn.Linear(768,256),
                                 nn.LayerNorm(256),
                                 nn.ReLU(),
                                 nn.Dropout(dropout),
                                 nn.Linear(256,128),
                                 nn.ReLU(),
                                 nn.Dropout(dropout),
                                 nn.Linear(128,8))
    def forward(self,sen,mask):
        y = self.erniemodel(sen,input_mask=mask)[1]
        return self.fc1(y)